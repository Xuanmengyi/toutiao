<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>

<style scoped>
.box {
  width: 700px;
  height: 88px;
  background-color: green;
}
</style>
